import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, signOut, sendEmailVerification } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDGFZM-CtZLVefMFWXOx93QSKCMPklztHc",
  authDomain: "biblioteca-utsc.firebaseapp.com",
  projectId: "biblioteca-utsc",
  storageBucket: "biblioteca-utsc.firebasestorage.app",
  messagingSenderId: "567175600539",
  appId: "1:567175600539:web:945e36a5c079fcc066693e"
};  

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

onAuthStateChanged(auth, (user) => {
    const isBiblioteca = window.location.pathname.includes('biblioteca.html');
    const isLogin = window.location.pathname.includes('login.html');
    const isRegistro = window.location.pathname.includes('registro.html');
    
    const emailDisplay = document.getElementById('user-email-display');
    const authBtn = document.getElementById('logout-btn'); 

    if (user && user.emailVerified) {
        // --- ESTADO: CON SESIÓN VERIFICADA ---
        if (emailDisplay) emailDisplay.textContent = user.email; 
        
        if (authBtn) {
            authBtn.textContent = "Cerrar Sesión";
            authBtn.style.background = "red";
            authBtn.onclick = () => {
                signOut(auth).then(() => { window.location.href = "login.html"; });
            };
        }

        if (isLogin || isRegistro) window.location.href = "biblioteca.html";
        if (isBiblioteca) cargarCatalogo();
    } else {
        // --- ESTADO: SIN SESIÓN O NO VERIFICADO ---
        if (emailDisplay) emailDisplay.textContent = "Sesión de invitado"; 

        if (authBtn) {
            authBtn.textContent = "Iniciar Sesión";
            authBtn.style.background = "var(--primary-green)"; 
            authBtn.onclick = () => { window.location.href = "login.html"; };
        }

        if (isBiblioteca) {
            alert("Acceso denegado: Debes iniciar sesión con una cuenta verificada.");
            window.location.href = "login.html";
        }
    }
}); 

const validarDominio = (email) => email.endsWith('@virtual.utsc.edu.mx');

const errorMsg = document.getElementById('error-msg');
const successMsg = document.getElementById('success-msg');

function mostrarMensaje(elemento, mensaje, esError = true) {
    if (elemento) {
        elemento.textContent = mensaje;
        elemento.style.display = 'block';
        elemento.style.color = esError ? 'red' : 'var(--primary-green)';
    }
}

// LÓGICA DE INICIO DE SESIÓN
const btnLogin = document.getElementById('btn-login');
if (btnLogin) {
    btnLogin.onclick = async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        
        if (!email || !password) { mostrarMensaje(errorMsg, "Faltan datos (Error 400)"); return; }
        if (!validarDominio(email)) { mostrarMensaje(errorMsg, "Solo se permiten correos @virtual.utsc.edu.mx"); return; }
        
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            
            // Bloquear acceso si el correo no está verificado
            if (!userCredential.user.emailVerified) {
                await signOut(auth);
                mostrarMensaje(errorMsg, "Por favor, verifica tu correo en tu bandeja de entrada antes de ingresar.");
            }
        } catch (error) {
            mostrarMensaje(errorMsg, "Credenciales inválidas o correo no registrado.");
        }
    };
}

// LÓGICA DE REGISTRO
const btnRegistrar = document.getElementById('btn-registrar');
if (btnRegistrar) {
    btnRegistrar.onclick = async (e) => {
        e.preventDefault();
        const email = document.getElementById('reg-email').value.trim();
        const password = document.getElementById('reg-password').value;
        const confirmPassword = document.getElementById('reg-confirm').value;
        
        if(errorMsg) errorMsg.style.display = 'none';
        if(successMsg) successMsg.style.display = 'none';

        if (!email || !password || !confirmPassword) { mostrarMensaje(errorMsg, "Todos los campos son obligatorios."); return; }
        if (!validarDominio(email)) { mostrarMensaje(errorMsg, "Solo se permiten correos @virtual.utsc.edu.mx"); return; }
        if (password !== confirmPassword) { mostrarMensaje(errorMsg, "Las contraseñas no coinciden."); return; }
        if (password.length < 6) { mostrarMensaje(errorMsg, "La contraseña debe tener al menos 6 caracteres."); return; }

        try {
            // 1. Crear usuario
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            
            // 2. Enviar correo de verificación
            await sendEmailVerification(userCredential.user);
            
            // 3. Cerrar sesión temporalmente para obligar a verificar
            await signOut(auth);
            
            // 4. Mostrar éxito y limpiar formulario
            mostrarMensaje(successMsg, "¡Registro exitoso! Revisa tu bandeja de entrada o SPAM para verificar tu cuenta.", false);
            document.getElementById('registro-form').reset();

        } catch (error) {
            if (error.code === 'auth/email-already-in-use') {
                mostrarMensaje(errorMsg, "Este correo ya está registrado.");
            } else {
                mostrarMensaje(errorMsg, `Error de registro: ${error.message}`);
            }
        }
    };
}

const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) logoutBtn.onclick = () => signOut(auth);

async function cargarCatalogo() {
    const contenedor = document.getElementById('catalogo-libros');
    contenedor.innerHTML = '<p>Cargando datos seguros desde Firestore...</p>';

    try {
        const querySnapshot = await getDocs(collection(db, "libros"));
        contenedor.innerHTML = '';
        
        if(querySnapshot.empty) {
            contenedor.innerHTML = '<p>No hay libros aún. Agrégalos desde Firebase Console.</p>';
            return;
        }

        const seccionesUnicas = new Set();

        querySnapshot.forEach((doc) => {
            const libro = doc.data();
            const seccionLibro = libro.Seccion || 'General';
            seccionesUnicas.add(seccionLibro);

            const card = document.createElement('div');
            card.className = 'card libro-item';
            card.dataset.seccion = seccionLibro; 
            
            card.innerHTML = `
                <span class="badge">${seccionLibro}</span>
                <h3 class="titulo" style="margin-bottom: 5px;">${libro.Titulo || 'Título no disponible'}</h3>
                <div style="margin-bottom: 15px;">
                    <p class="autor" style="font-size: 12px; color: #555;">Autor: ${libro.Autor || 'N/A'}</p>
                    <p class="editorial" style="font-size: 12px; color: #555;">Editorial: ${libro.Editorial || 'N/A'}</p>
                    <p class="isbn" style="font-size: 12px; color: #555;">ISBN: ${libro.ISBN || libro.Isbn || libro.isbn || 'N/A'}</p>
                </div>
                <hr style="margin: 10px 0; border: 0; border-top: 1px solid #eee;">
                <p class="resumen" style="font-size: 19px;"><strong>Resumen:</strong> ${libro.Resumen || 'Sin resumen'}</p>`;
            contenedor.appendChild(card);
        });

        configurarBuscadorAvanzado(seccionesUnicas);

    } catch (error) {
        contenedor.innerHTML = '<p>Error de conexión con la base de datos (Error 500).</p>';
    }
}

function configurarBuscadorAvanzado(seccionesUnicas) {
    const buscador = document.getElementById('buscador');
    const searchBar = document.getElementById('search-bar');
    const customSelect = document.getElementById('custom-select');
    const filtroTexto = document.getElementById('filtro-texto');
    const opcionesContainer = document.getElementById('custom-options');
    let seccionActiva = "";

    if (opcionesContainer) {
        opcionesContainer.innerHTML = '<div class="custom-option selected" data-value="">Todas las áreas</div>';
        seccionesUnicas.forEach(seccion => {
            opcionesContainer.innerHTML += `<div class="custom-option" data-value="${seccion}">${seccion}</div>`;
        });
    }

    function filtrarLibros() {
        const termino = buscador ? buscador.value.toLowerCase() : "";
        document.querySelectorAll('.libro-item').forEach(tarjeta => {
            const textoTarjeta = tarjeta.textContent.toLowerCase();
            const seccionTarjeta = tarjeta.dataset.seccion;
            const coincideTexto = textoTarjeta.includes(termino);
            const coincideSeccion = seccionActiva === "" || seccionTarjeta === seccionActiva;
            tarjeta.style.display = (coincideTexto && coincideSeccion) ? 'block' : 'none';
        });
    }

    if (buscador) buscador.oninput = filtrarLibros;

    if (customSelect) {
        customSelect.onclick = (e) => {
            e.stopPropagation(); 
            searchBar.classList.toggle('menu-open');
        };

        document.querySelectorAll('.custom-option').forEach(opcion => {
            opcion.onclick = (e) => {
                e.stopPropagation();
                seccionActiva = e.target.getAttribute('data-value');
                filtroTexto.textContent = e.target.textContent;
                
                filtroTexto.style.color = "#333";
                
                document.querySelectorAll('.custom-option').forEach(opt => opt.classList.remove('selected'));
                e.target.classList.add('selected');
                
                searchBar.classList.remove('menu-open'); 
                filtrarLibros();

                if (buscador) buscador.focus();
            };
        });

        document.onclick = (e) => {
            if (!customSelect.contains(e.target)) searchBar.classList.remove('menu-open');
        };
    }
}